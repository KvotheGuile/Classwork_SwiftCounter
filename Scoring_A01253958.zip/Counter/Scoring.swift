//
//  Scoring.swift
//  Counter
//
//  Created by MAC on 17/11/26.
//

//
//  ContentView.swift
//  Counter
//
//  Created by MAC on 17/11/26.
//

import SwiftUI

struct Scoring: View {
    @State private var countA = 0
    @State private var countB = 0
    
    var body: some View {
        
        VStack{
            
            Text("SCORING").font(.title).bold()
            
            HStack
            {
                VStack (spacing: 24) {
                    Text("Team 1")
                        .font(.title3)
                        .bold()
                    Text("\(countA)")
                        .font(.system(size: 48, weight: .bold))
                    
                        .foregroundStyle(countA >= 10 ? Color.green : Color.primary)
                    
                        .contentTransition(.numericText())
                    
                    HStack(spacing: 16){
                        Button {
                            withAnimation{
                                countA -= 1
                            }
                        } label: {
                            Image(systemName: "minus")
                                .frame(width: 40, height: 30)
                        }
                        .buttonStyle(.bordered)
                        .disabled(countA <= 0)
                        
                        Button {
                            withAnimation{
                                countA += 1
                            }
                        } label: {
                            Image(systemName: "plus")
                                .frame(width: 40, height: 30)
                        }.buttonStyle(.borderedProminent)
                    }
                    .font(.title)
                    
                    
                }
                .padding()
                .tint(.green)
                
                Text("vs").foregroundStyle(.gray)
                
                VStack (spacing: 24) {
                    Text("Team 2")
                        .font(.title3)
                        .bold()
                    Text("\(countB)")
                        .font(.system(size: 48, weight: .bold))
                    
                        .foregroundStyle(countB >= 10 ? Color.indigo : Color.primary)
                    
                        .contentTransition(.numericText())
                    
                    HStack(spacing: 16){
                        Button {
                            withAnimation{
                                countB -= 1
                            }
                        } label: {
                            Image(systemName: "minus")
                                .frame(width: 40, height: 30)
                        }
                        .buttonStyle(.bordered)
                        .disabled(countB <= 0)
                        
                        Button {
                            withAnimation{
                                countB += 1
                            }
                        } label: {
                            Image(systemName: "plus")
                                .frame(width: 40, height: 30)
                        }.buttonStyle(.borderedProminent)
                    }
                    .font(.title)
                    
                    
                }
                .padding()
                .tint(.indigo)
                
                
            }
            
            
            Button("Restart", role: .destructive){
                countA = 0
                countB = 0
            }.foregroundStyle(.red)
            
            
            if countA == countB {
                Text("Draw")
                    .font(.headline)
            }
            else if countA > countB{
                Text("Team 1 is winning")
                    .font(.headline)
            }else{
                Text("Team 2 is winning")
                    .font(.headline)
            }
            
        }
        
    }
}

#Preview {
    Scoring()
}

