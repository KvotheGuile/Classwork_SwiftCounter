//
//  ContentView.swift
//  Counter
//
//  Created by MAC on 17/11/26.
//

import SwiftUI

struct ContentView: View {
    @State private var count = 0
    
    var body: some View {
        VStack (spacing: 24) {
            Text("Counter")
                .font(.largeTitle)
                .bold()
            Text("\(count)")
                .font(.system(size: 96, weight: .bold))
            
                .foregroundStyle(count >= 10 ? Color.blue : Color.primary)
            
                .contentTransition(.numericText())
            
            HStack(spacing: 16){
                Button {
                    withAnimation{
                        count -= 1
                    }
                } label: {
                    Image(systemName: "minus")
                        .frame(width: 60, height: 44)
                }
                .buttonStyle(.bordered)
                .disabled(count <= 0)
                
                Button {
                    withAnimation{
                        count += 1
                    }
                } label: {
                    Image(systemName: "plus")
                        .frame(width: 60, height: 44)
                }.buttonStyle(.borderedProminent)
            }
            .font(.title)
            
            Button("Restart", role: .destructive){
                count = 0
            }.foregroundStyle(.red)
            
            if count >= 10 {
                Text("You got to 10!")
                    .font(.headline)
            }
            
            
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
