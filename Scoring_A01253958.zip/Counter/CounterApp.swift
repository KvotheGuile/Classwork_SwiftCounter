//
//  CounterApp.swift
//  Counter
//
//  Created by MAC on 17/11/26.
//

import SwiftUI

@main
struct CounterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
